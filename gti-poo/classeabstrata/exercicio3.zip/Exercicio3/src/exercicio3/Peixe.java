
package exercicio3;


public class Peixe extends Animal{
    
    @Override
    public void locomover(){
        System.out.println("Nadando...");    
    }

    @Override
    public void emitirSom() {
        
    }

    @Override
    public void comer() {
        
    }
    
}
