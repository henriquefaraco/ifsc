
package exercicio3;


public class Mamifero extends Animal {

    public String corPelo;
    
    public void amamentar(){
        
    }

    @Override
    public void emitirSom() {
        
    }

    @Override
    public void locomover() {
        
    }

    @Override
    public void comer() {
       
    }
    
}
