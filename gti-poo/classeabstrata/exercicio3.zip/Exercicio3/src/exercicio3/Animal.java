
package exercicio3;

public abstract class Animal {

    private String nome;
    private String nomeCientifico;
    private String habitat;
    private int numPatas;
    
    public abstract void emitirSom();
    
    public abstract void locomover();
    
    public abstract void comer();
    
    
}
