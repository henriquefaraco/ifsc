
package exercicio3;

public class Exercicio3 {

    public static void main(String[] args) {
    
        Animal animal1 = new Animal();
        
    }
    
}
