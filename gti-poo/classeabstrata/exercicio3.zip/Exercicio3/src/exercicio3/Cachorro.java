
package exercicio3;

public class Cachorro extends Mamifero{
    
    @Override
    public void emitirSom(){
        System.out.println("au au au...");
    }
    
    
}
