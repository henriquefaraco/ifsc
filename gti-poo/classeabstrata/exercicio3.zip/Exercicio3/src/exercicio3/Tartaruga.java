
package exercicio3;


public class Tartaruga extends Reptil{
    
    @Override
    public void locomover(){
        System.out.println("Andando...");
    }
    
    
}
