
package exercicio3;


public class Reptil extends Animal {

    public String corEscamas;
    
    public void porOvos(){
        
    }
    @Override
    public void locomover(){
        System.out.println("Rastejando...");
        
    }

    @Override
    public void emitirSom() {
        
    }

    @Override
    public void comer() {
        
    }
}
