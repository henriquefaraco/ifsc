
package exercicio3;

public class Tubarao extends Peixe{
    
    
    
    
}
