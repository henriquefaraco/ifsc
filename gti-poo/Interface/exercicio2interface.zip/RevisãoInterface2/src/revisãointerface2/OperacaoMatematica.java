
package revisãointerface2;

public interface OperacaoMatematica {
    
    public void calcular(int valor1, int valor2);
    
}
