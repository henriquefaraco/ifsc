
package hamburgueria;


public class Hamburgueria {


    public static void main(String[] args) {
    
    }
    
}
